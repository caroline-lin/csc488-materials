package compiler488.ast.expn;

/**
 * This is a place holder for literal constants.
 */
public abstract class ConstExpn extends Expn {
}
